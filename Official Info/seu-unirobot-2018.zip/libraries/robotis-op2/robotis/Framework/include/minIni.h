/*
 *   minIni.h
 *   minIni - Multi-Platform INI file parser, suitable for embedded systems
 *   Author: ROBOTIS
 *
 */

#ifndef _INC_MININI_H_
#define _INC_MININI_H_

#include "../src/minIni/minIni.h"

#endif
